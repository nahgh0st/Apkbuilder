package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerrariaDarkColorScheme = darkColorScheme(
    primary = TerrariaGreen,
    onPrimary = Color.Black,
    secondary = ManaBlue,
    onSecondary = Color.Black,
    tertiary = GoldYellow,
    background = DarkBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextPrimary,
    error = LifeRed,
    onError = Color.White
)

// We keep a light color scheme as a fallback, but game server console uses cohesive dark theme!
private val TerrariaLightColorScheme = lightColorScheme(
    primary = TerrariaGreen,
    onPrimary = Color.White,
    secondary = ManaBlue,
    onSecondary = Color.White,
    tertiary = GoldYellow,
    background = Color(0xFFAEC4D1),
    onBackground = Color(0xFF0C0F12),
    surface = Color.White,
    onSurface = Color(0xFF0C0F12),
    surfaceVariant = Color(0xFFE3E9F0),
    onSurfaceVariant = Color(0xFF222B36),
    error = LifeRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium dark look by default for Terraria hosts!
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) TerrariaDarkColorScheme else TerrariaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
