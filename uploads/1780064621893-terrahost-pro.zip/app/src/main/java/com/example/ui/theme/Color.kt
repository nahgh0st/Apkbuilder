package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Palette
val DarkBg = Color(0xFF0C0F12)
val DarkSurface = Color(0xFF161C23)
val DarkSurfaceVariant = Color(0xFF222B36)

val TerrariaGreen = Color(0xFF55BA58)
val ManaBlue = Color(0xFF00D2FF)
val LifeRed = Color(0xFFE53935)
val GoldYellow = Color(0xFFFFB300)

val TextPrimary = Color(0xFFE3E9F0)
val TextSecondary = Color(0xFF8F9CAE)
